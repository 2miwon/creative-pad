import SwiftUI

struct LandingView: View {
    var body: some View {
        Text("Hello, World!")
    }
}

#Preview {
    LandingView()
}
